class User {
    constructor(obj){
        this.first_name = obj.first_name;
        this.last_name = obj.last_name;
        this.email = obj.email;
        this.contact = obj.contact;
        this.imageUrl = obj.imageUrl;
    }
}

module.exports = User;