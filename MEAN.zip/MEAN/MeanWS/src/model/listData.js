const connection = require("../utilities/connection");
const listUsers = {};

listUsers.listUsers=()=>{
    console.log("in model")
    return connection.getUsersCollection().then((data)=>{
        return data.find().then((data)=>{
            console.log(data)
            if(data!=null){
                console.log("returning response")
                return data
            }else{
                return "No users found"
            }
        })
        
    })
}

listUsers.getDetails=(email)=>{
    return connection.getUsersCollection().then((collection)=>{
        return collection.findOne({"email":email}).then((data)=>{
            if(data!=null){
                return data
            }else{
                return "User with given email id is not present"
            }
        })
    })
}

module.exports = listUsers;
