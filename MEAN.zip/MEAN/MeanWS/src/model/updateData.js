const connection = require("../utilities/connection")
const userDetails = require("./beanClass/users")
const collection = require("../utilities/connection")

const userDB ={}

userDB.checkEmail = ( userDetails) =>{
    return connection.getUsersCollection().then((collection)=>{
        return collection.findOne({"email":userDetails.email}).then((userEmail)=>{
            if(userEmail!=null){
                return "user already present"
            }else {
                return collection.create({
                    "fisrt_name":userDetails.fisrt_name,
                    "last_name":userDetails.last_name,
                    "email":userDetails.email,
                    "contact":userDetails.contact,
                    "imageUrl":userDetails.imageUrl
                }).then((updatedData)=>{
                    if (updatedData){
                        return updatedData
                    }
                })
            }
        })
    })
}

module.exports = userDB