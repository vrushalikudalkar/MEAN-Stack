const connection = require("../utilities/connection");
const collection = require("../utilities/connection");

const deleteUser = {}

deleteUser.deleteUser=(first_name)=>{
    return connection.getUsersCollection().then((data)=>{
        return data.deleteOne({"first_name":first_name}).then((data)=>{
            console.log(data)
        })
    })

}

module.exports = deleteUser