const connection = require("../utilities/connection")

// let userData = [
//     {
//         first_name:"pratiksha", 
//         last_name:"shah", 
//         email:"pratiksha@shah", 
//         contact:1234567890,
//         imageUrl:"/assets/user1.jpg"
//     },
//     {
//         first_name:"sagar",
//         last_name:"sharma",
//         email:"sagar@sharma",
//         contact:5678908765,
//         imageUrl:"assests/user2.jpg"
//     }
// ]

exports.createUser = (postdata)=>{
    console.log("in model", postdata)
    return connection.getUsersCollection().then((newCollection)=>{
        return newCollection.create(postdata).then((data)=>{
            console.log(data)
            if(data!=null){
                return "new user created"
            }else{
                return "user not created"
            }
        })
    })
}