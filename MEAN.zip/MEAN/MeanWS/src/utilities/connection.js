const{ Schema } = require("mongoose");
const Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
const url = "mongodb://localhost:27017/userData";
let userSchema = Schema({
    first_name: String,
    last_name: String,
    email: String,
    contact: Number,
    imageUrl: String
}, {collection:"users"})

let collection = {}
collection.getUsersCollection = ()=>{
    return Mongoose.connect(url,  {useNewUrlParser:true}).then((database)=>{
        return database.model('users', userSchema)
    }).catch((error)=>{
        let err = new Error("could not connect to database");
        err.status = 500;
        throw err
    })
}

module.exports = collection;