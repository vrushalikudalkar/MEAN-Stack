const upadteData = require("../model/updateData");

const updateDataSrv = {};

updateDataSrv.upadteData = (userDetails) =>{
    return upadteData.upadteData(userDetails).then((data)=>{
        if(data){
            return data.email
        }
    })
}