const express = require("express");
const router = express.Router();
const listUsers = require("../model/listData")

router.get("/list",(req,res,next)=>{
    console.log("in ruter")
    listUsers.listUsers().then((data)=>{
        console.log("back in router",data)
        res.setHeader('Content-Type', 'application/json')
        res.json(data)
        // console.log(res)
    }).catch(err => next(err));
})

router.get("/view/:email",(req,res,next)=>{
    email=req.params.email
    listUsers.getDetails(email).then((data)=>{
        res.json(data)
    }).catch(err=>next(err))
})

module.exports = router;