const express = require("express");
const router = express.Router();
const updateData = require("../service/updateData")
const userDetails = require("../model/beanClass/users")


router.put("/update",(req, res, next)=>{
    const userDetails = new userDetails(req.body)
    updateData.updateData(userDetails).then((email)=>{
        res.json({"message":"successfully updated"})
    }).catch(err => next(err));
})

module.exports = router;