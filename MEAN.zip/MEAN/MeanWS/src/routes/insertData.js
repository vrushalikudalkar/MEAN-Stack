const express = require("express");
const router = express.Router();
const createUser = require("../model/insertData");

router.post("/create",(req,res,next)=>{
    createUser.createUser(req.body).then((userData)=>{
        res.send(userData)
    }).catch(err=>next(err));
})

module.exports = router;