const express = require("express");
const router = express.Router();
const deleteUser = require("../model/deleteData")

router.delete("/delete/:first_name",(req,res,next)=>{
    
    name = req.params.first_name
    console.log("in delete route")
    deleteUser.deleteUser(name).then((name)=>{
        res.json({"message":"successfully deleted user"+name})
    }).catch(err=>next(err));
})

module.exports = router;