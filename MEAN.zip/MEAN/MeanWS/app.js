const express = require('express');
const bodyParser = require("body-parser");
const cors = require('cors');
const createUser = require('./src/routes/insertData');
const updateUser = require("./src/routes/updateData");
const listUsers = require("./src/routes/listData")
const deleteUser = require("./src/routes/deleteData")
const app = express();
const port = process.env.SERVER_PORT || 3000;
app.use(cors());
app.use('/', createUser);
app.use('/', updateUser);
app.use('/', listUsers);
app.use('/', deleteUser);

app.use(bodyParser.json());


app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})