import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import {User} from './../model/user'

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  baseURL = 'http://localhost:3000'; 
  headers = new HttpHeaders().set('Content-Type', 'application/json');
  
  constructor(private http: HttpClient) { }

  //create user
  createUser(data:any):Observable<User>{
    console.log(data);
    let url = 'http://localhost:3000/create'
    return <Observable<User>> this.http.post(url,data);
  }

  listAllUsers(){
    let url = 'http://localhost:3000/list'
    return this.http.get(url)
  }

  deleteUser(name:any):Observable<any>{
    let url = 'http://localhost:3000/delete/:name'
    return this.http.delete(url,{headers:this.headers});
  }

  updateUser(email , data): Observable<any> {
    let url = 'http://localhost:3000/update/:email';
    return this.http.put(url, data, { headers: this.headers })
  }

  getUser(email):Observable<any> {
    let url = 'http://localhost:3000/view/:email';
    return this.http.get(url,{headers: this.headers})
  }
}
