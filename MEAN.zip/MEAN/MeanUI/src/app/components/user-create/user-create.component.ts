import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../service/api.service';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.css']
})
export class UserCreateComponent implements OnInit {
  submitted: boolean =false
  value:boolean = true
  constructor(private fb:FormBuilder, private apiService: ApiService) { }
  createForm : FormGroup
  

  ngOnInit() {
    this.createForm = this.fb.group({
      first_name: ['',[Validators.required, Validators.pattern('^[A-z]+[]*[A-z]*$')]],
      last_name: ['',[Validators.required, Validators.pattern('^[A-z]+[]*[A-z]*$')]],
      email: ['',[Validators.required,Validators.pattern('/[A-z]@[A-z]/')]],
      contact:['',[Validators.required, Validators.pattern('^[0-9]{10}')]]
    })
  }


  create(){
    this.submitted = true
    let data = this.createForm.value
    this.apiService.createUser(data).subscribe((res)=>{
      this.value = false
    }, (error) => {
      console.log(error)
    })
  }
}
