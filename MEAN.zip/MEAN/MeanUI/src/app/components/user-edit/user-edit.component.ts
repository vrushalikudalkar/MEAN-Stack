import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../service/api.service';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { User} from './../../model/user'
import { ActivatedRoute, Router  } from '@angular/router';


@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {
  submitted = false;
  editForm: FormGroup;
  euserData: User[];

  constructor(private fb:FormBuilder, private apiService:ApiService, private aRoute:ActivatedRoute, private router:Router) { }

  ngOnInit() {
    this.updateUser()
    let email = this.aRoute.snapshot.paramMap.get('email');
    this.userToBeUpdated(email);
    this.editForm = this.fb.group({
      first_name: ['',[Validators.required, Validators.pattern('^[A-z]+[]*[A-z]*$')]],
      last_name: ['',[Validators.required, Validators.pattern('^[A-z]+[]*[A-z]*$')]],
      email: ['',[Validators.required,Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      contact:['',[Validators.required, Validators.pattern('^[0-9]{10}')]],
      imageUrl:['']
    })
  }

  userToBeUpdated(email) {
    this.apiService.getUser(email).subscribe(data => {
      this.editForm.setValue({
        first_name: data['first_name'],
        last_name: data['last_name'],
        email: data['email'],
        contact: data['contact'],
        imageUrl: data['imageUrl'],
      });
    });
  }

  updateUser(){
    this.editForm = this.fb.group({
      first_name: ['',[Validators.required, Validators.pattern('^[A-z]+[]*[A-z]*$')]],
      last_name: ['',[Validators.required, Validators.pattern('^[A-z]+[]*[A-z]*$')]],
      email: ['',[Validators.required,Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      contact:['',[Validators.required, Validators.pattern('^[0-9]{10}')]],
      imageUrl:['']
    })
  }

  update(){
    this.submitted = true
    if (!this.editForm.valid){
      return "invalid data"
    }else{
      if(window.confirm("Do you want to proceed?")){
        let email = this.aRoute.snapshot.paramMap.get('email');
        this.apiService.updateUser(email, this.editForm.controls.value).subscribe((data)=>{
          this.router.navigateByUrl('/update')
          console.log("data updated successfully!")
        }),(err)=>{
          console.log(err)
        }
      }
    }
  }
}
