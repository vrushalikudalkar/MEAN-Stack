import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../service/api.service';

@Component({
  selector: 'app-user-view',
  templateUrl: './user-view.component.html',
  styleUrls: ['./user-view.component.css']
})
export class UserViewComponent implements OnInit {
  User: any = []
  constructor(private apiService:ApiService) {
    this.listUser()
  }

  ngOnInit() {
  }

  listUser(){
    this.apiService.listAllUsers().subscribe((data)=>{
      this.User = data
    })
  }

  deleteUser(user,index){
    if(window.confirm("Do you want to delete this user?")){
      this.apiService.deleteUser(user.email).subscribe((data)=>{
        this.User.splice(index, 1)
      })
    }
  }

}
