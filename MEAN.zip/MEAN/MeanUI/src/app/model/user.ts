export class User {
    first_name:string;
    last_name: string;
    email: string;
    contact: number;
    image_url:string;
}
